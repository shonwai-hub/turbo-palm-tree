import React, { useState } from 'react';
import { Users, DollarSign, Send, PlusCircle, X } from 'lucide-react';
import { Client, Quotation } from '../types';
import { generateQuotation } from '../services/geminiService';

interface CrmModuleProps {
  clients: Client[];
  setClients: React.Dispatch<React.SetStateAction<Client[]>>;
}

const CrmModule: React.FC<CrmModuleProps> = ({ clients, setClients }) => {
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [showQuoteModal, setShowQuoteModal] = useState(false);
  
  // Quote State
  const [quoteItems, setQuoteItems] = useState<{description: string, cost: number}[]>([{ description: '', cost: 0 }]);
  const [margin, setMargin] = useState(20);
  const [generatedQuote, setGeneratedQuote] = useState<{emailBody: string, totalPrice: number} | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleAddItem = () => {
    setQuoteItems([...quoteItems, { description: '', cost: 0 }]);
  };

  const updateItem = (index: number, field: 'description' | 'cost', value: string | number) => {
    const newItems = [...quoteItems];
    if (field === 'cost') {
      newItems[index].cost = Number(value);
    } else {
      newItems[index].description = value as string;
    }
    setQuoteItems(newItems);
  };

  const handleGenerateQuote = async () => {
    if (!selectedClient) return;
    setIsGenerating(true);
    const result = await generateQuotation(selectedClient.contactPerson, quoteItems, margin);
    setGeneratedQuote(result);
    setIsGenerating(false);
  };

  const openQuoteModal = (client: Client) => {
    setSelectedClient(client);
    setQuoteItems([{ description: '', cost: 0 }]);
    setGeneratedQuote(null);
    setShowQuoteModal(true);
  };

  return (
    <div className="h-full flex flex-col bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden relative">
      <div className="p-6 border-b border-slate-100 bg-slate-50">
        <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
          <Users className="w-6 h-6 text-primary" />
          CRM & Sales
        </h2>
      </div>

      <div className="flex-1 overflow-auto">
        <table className="w-full text-left border-collapse">
          <thead className="bg-slate-50 sticky top-0 z-10">
            <tr>
              <th className="p-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Company</th>
              <th className="p-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Contact</th>
              <th className="p-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Status</th>
              <th className="p-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {clients.map(client => (
              <tr key={client.id} className="hover:bg-slate-50 transition-colors">
                <td className="p-4 font-medium text-slate-800">{client.companyName}</td>
                <td className="p-4 text-slate-600">
                  <div className="flex flex-col">
                    <span>{client.contactPerson}</span>
                    <span className="text-xs text-slate-400">{client.email}</span>
                  </div>
                </td>
                <td className="p-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    client.status === 'Closed' ? 'bg-green-100 text-green-700' :
                    client.status === 'Negotiation' ? 'bg-amber-100 text-amber-700' :
                    'bg-blue-100 text-blue-700'
                  }`}>
                    {client.status}
                  </span>
                </td>
                <td className="p-4">
                  <button 
                    onClick={() => openQuoteModal(client)}
                    className="text-sm text-primary hover:text-blue-700 font-medium flex items-center gap-1"
                  >
                    <DollarSign className="w-4 h-4" /> Create Quote
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Quotation Modal */}
      {showQuoteModal && selectedClient && (
        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90%] flex flex-col overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h3 className="font-bold text-lg text-slate-800">New Quotation for {selectedClient.companyName}</h3>
              <button onClick={() => setShowQuoteModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto flex-1 space-y-6">
              {/* Line Items */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Line Items (Cost)</label>
                {quoteItems.map((item, idx) => (
                  <div key={idx} className="flex gap-2 mb-2">
                    <input 
                      type="text" 
                      placeholder="Item Description"
                      className="flex-1 border border-slate-300 rounded px-3 py-2 text-sm"
                      value={item.description}
                      onChange={(e) => updateItem(idx, 'description', e.target.value)}
                    />
                    <input 
                      type="number" 
                      placeholder="Cost"
                      className="w-24 border border-slate-300 rounded px-3 py-2 text-sm"
                      value={item.cost}
                      onChange={(e) => updateItem(idx, 'cost', e.target.value)}
                    />
                  </div>
                ))}
                <button onClick={handleAddItem} className="text-sm text-primary flex items-center gap-1 mt-2">
                  <PlusCircle className="w-4 h-4" /> Add Item
                </button>
              </div>

              {/* Margin */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Target Margin (%)</label>
                <input 
                  type="range" 
                  min="0" 
                  max="100" 
                  value={margin} 
                  onChange={(e) => setMargin(Number(e.target.value))}
                  className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                />
                <div className="text-right text-sm font-bold text-slate-600 mt-1">{margin}%</div>
              </div>

              {/* Action */}
              <div className="flex justify-end">
                <button 
                  onClick={handleGenerateQuote}
                  disabled={isGenerating}
                  className="bg-primary text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors disabled:opacity-50"
                >
                  {isGenerating ? 'Calculating...' : 'Generate Quote with AI'}
                </button>
              </div>

              {/* Result */}
              {generatedQuote && (
                <div className="mt-6 border-t border-slate-100 pt-4 animate-in fade-in slide-in-from-bottom-4">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-sm font-medium text-slate-500">Total Quoted Price:</span>
                    <span className="text-2xl font-bold text-green-600">${generatedQuote.totalPrice.toFixed(2)}</span>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                    <h4 className="text-xs font-bold text-slate-500 uppercase mb-2">Draft Email</h4>
                    <p className="text-sm text-slate-700 whitespace-pre-wrap font-mono">{generatedQuote.emailBody}</p>
                  </div>
                  <button className="w-full mt-4 bg-green-600 text-white py-2 rounded-lg font-medium hover:bg-green-700 flex items-center justify-center gap-2">
                    <Send className="w-4 h-4" /> Send Quotation
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CrmModule;
