import React from 'react';
import { AlertTriangle, CheckCircle, Clock, TrendingUp, Mail, Users, ArrowRight, ShieldAlert } from 'lucide-react';
import { Email, Client, EmailCategory } from '../types';

interface DashboardProps {
  emails: Email[];
  clients: Client[];
  navigateTo: (tab: 'email' | 'knowledge' | 'crm') => void;
  gmailConnected: boolean;
}

const Dashboard: React.FC<DashboardProps> = ({ emails, clients, navigateTo, gmailConnected }) => {
  // Derived State
  const urgentEmails = emails.filter(e => e.actionRequired);
  const activeDeals = clients.filter(c => c.status === 'Negotiation');
  const pendingLeads = clients.filter(c => c.status === 'Lead');
  
  // Mock System Alerts
  const systemAlerts = [
    { id: 1, message: "API Usage at 80% of daily limit", type: 'warning' },
    { id: 2, message: "New model 'Gemini 2.5' is now active", type: 'info' }
  ];

  return (
    <div className="h-full overflow-y-auto space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-xl p-8 text-white shadow-lg">
        <h2 className="text-3xl font-bold mb-2">Good Morning, John</h2>
        <p className="text-slate-300 max-w-2xl">
          You have <span className="font-bold text-white">{urgentEmails.length} urgent emails</span> and <span className="font-bold text-white">{activeDeals.length} active deals</span> requiring your attention today.
          {!gmailConnected && (
            <span className="block mt-2 text-amber-400 text-sm font-medium flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" /> Gmail is not connected. Connect now to enable AI inbox processing.
            </span>
          )}
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          icon={<Mail className="text-blue-600" />} 
          label="Unread Emails" 
          value={emails.length.toString()} 
          trend="+12%" 
          onClick={() => navigateTo('email')}
        />
        <StatCard 
          icon={<Users className="text-green-600" />} 
          label="Active Deals" 
          value={activeDeals.length.toString()} 
          trend="+5%" 
          onClick={() => navigateTo('crm')}
        />
        <StatCard 
          icon={<Clock className="text-amber-600" />} 
          label="Pending Leads" 
          value={pendingLeads.length.toString()} 
          trend="-2%" 
          onClick={() => navigateTo('crm')}
        />
        <StatCard 
          icon={<TrendingUp className="text-purple-600" />} 
          label="Conversion Rate" 
          value="24%" 
          trend="+1.5%" 
          onClick={() => navigateTo('crm')}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Urgent Alerts Column */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="p-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
              <h3 className="font-bold text-slate-800 flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-red-500" />
                Priority Alerts
              </h3>
              <span className="text-xs font-medium px-2 py-1 bg-red-100 text-red-700 rounded-full">
                {urgentEmails.length} Items
              </span>
            </div>
            <div className="divide-y divide-slate-100">
              {urgentEmails.length > 0 ? (
                urgentEmails.map(email => (
                  <div key={email.id} className="p-4 hover:bg-slate-50 transition-colors flex items-start gap-4">
                    <div className="mt-1">
                      <div className="w-2 h-2 rounded-full bg-red-500"></div>
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <h4 className="font-medium text-slate-900">{email.subject}</h4>
                        <span className="text-xs text-slate-400">{email.date}</span>
                      </div>
                      <p className="text-sm text-slate-600 mt-1 line-clamp-1">{email.summary || email.body}</p>
                      <div className="mt-2 flex gap-2">
                        <button 
                          onClick={() => navigateTo('email')}
                          className="text-xs font-medium text-primary hover:text-blue-700 flex items-center gap-1"
                        >
                          View Email <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center text-slate-400">
                  <CheckCircle className="w-12 h-12 mx-auto mb-2 opacity-20" />
                  <p>No urgent alerts. You're all caught up!</p>
                </div>
              )}
            </div>
          </div>

          {/* System Status */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
             <div className="p-4 border-b border-slate-100 bg-slate-50">
              <h3 className="font-bold text-slate-800">System Notifications</h3>
            </div>
            <div className="p-4 space-y-3">
              {systemAlerts.map(alert => (
                <div key={alert.id} className={`p-3 rounded-lg border flex items-center gap-3 ${
                  alert.type === 'warning' ? 'bg-amber-50 border-amber-200 text-amber-800' : 'bg-blue-50 border-blue-200 text-blue-800'
                }`}>
                  {alert.type === 'warning' ? <AlertTriangle className="w-5 h-5" /> : <CheckCircle className="w-5 h-5" />}
                  <span className="text-sm font-medium">{alert.message}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Quick Actions & CRM Snapshot */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="p-4 border-b border-slate-100 bg-slate-50">
              <h3 className="font-bold text-slate-800">Active Negotiations</h3>
            </div>
            <div className="divide-y divide-slate-100">
              {activeDeals.map(client => (
                <div key={client.id} className="p-4 hover:bg-slate-50 transition-colors">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-medium text-slate-900">{client.companyName}</span>
                    <span className="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">Neg.</span>
                  </div>
                  <p className="text-xs text-slate-500 mb-2">Contact: {client.contactPerson}</p>
                  <button 
                    onClick={() => navigateTo('crm')}
                    className="w-full py-1.5 text-xs font-medium border border-slate-200 rounded hover:bg-slate-50 text-slate-600"
                  >
                    Follow Up
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ icon, label, value, trend, onClick }: any) => (
  <div 
    onClick={onClick}
    className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 cursor-pointer hover:shadow-md transition-all"
  >
    <div className="flex justify-between items-start mb-4">
      <div className="p-2 bg-slate-50 rounded-lg">{icon}</div>
      <span className={`text-xs font-medium px-2 py-1 rounded-full ${
        trend.startsWith('+') ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
      }`}>
        {trend}
      </span>
    </div>
    <h3 className="text-2xl font-bold text-slate-900">{value}</h3>
    <p className="text-sm text-slate-500">{label}</p>
  </div>
);

export default Dashboard;
