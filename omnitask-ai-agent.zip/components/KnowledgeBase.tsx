import React, { useState } from 'react';
import { FileText, HardDrive, Cloud, Search, Sparkles, Plus, Check } from 'lucide-react';
import { DocumentFile } from '../types';
import { generateProposal } from '../services/geminiService';

interface KnowledgeBaseProps {
  documents: DocumentFile[];
  setDocuments: React.Dispatch<React.SetStateAction<DocumentFile[]>>;
  isDriveConnected: boolean;
  onConnectDrive: () => void;
}

const KnowledgeBase: React.FC<KnowledgeBaseProps> = ({ documents, setDocuments, isDriveConnected, onConnectDrive }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [prompt, setPrompt] = useState('');
  const [generatedContent, setGeneratedContent] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isConnectingDrive, setIsConnectingDrive] = useState(false);

  // Mock file upload
  const handleFileUpload = () => {
    const newDoc: DocumentFile = {
      id: Date.now().toString(),
      name: `New_Proposal_Draft_${documents.length + 1}.pptx`,
      type: 'pptx',
      source: 'Local',
      contentSnippet: "This is a simulated content snippet for a newly uploaded file. It contains details about project timelines and deliverables.",
      tags: ['draft', 'upload']
    };
    setDocuments([...documents, newDoc]);
  };

  const handleConnectDrive = () => {
    setIsConnectingDrive(true);
    setTimeout(() => {
      setIsConnectingDrive(false);
      onConnectDrive();
      // Simulate fetching new files from drive
      const newDriveFiles: DocumentFile[] = [
        { id: 'd1', name: 'Q3_Financials.xlsx', type: 'docx', source: 'Google Drive', contentSnippet: 'Q3 Financial projections show 20% growth.', tags: ['finance', 'q3'] },
        { id: 'd2', name: 'Marketing_Assets_2024.pdf', type: 'pdf', source: 'Google Drive', contentSnippet: 'Brand guidelines and logo usage.', tags: ['marketing', 'brand'] }
      ];
      setDocuments(prev => [...prev, ...newDriveFiles]);
    }, 1500);
  };

  const handleGenerate = async () => {
    if (!prompt) return;
    setIsGenerating(true);
    
    // Filter docs based on search query to simulate "selecting" relevant files
    const relevantDocs = searchQuery 
      ? documents.filter(d => d.name.toLowerCase().includes(searchQuery.toLowerCase()) || d.tags.some(t => t.includes(searchQuery)))
      : documents;

    const result = await generateProposal(prompt, relevantDocs);
    setGeneratedContent(result);
    setIsGenerating(false);
  };

  const filteredDocs = documents.filter(d => 
    d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="h-full grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Left: File Explorer */}
      <div className="lg:col-span-1 bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50">
          <h2 className="font-bold text-slate-800 flex items-center gap-2">
            <HardDrive className="w-5 h-5 text-primary" />
            Knowledge Base
          </h2>
          <div className="mt-3 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search files..." 
              className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {/* Drive Connection Banner */}
        {!isDriveConnected ? (
          <div className="p-4 bg-blue-50 border-b border-blue-100">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-white rounded-full shadow-sm">
                <Cloud className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-bold text-blue-900">Connect Google Drive</h3>
                <p className="text-xs text-blue-700 mt-1 mb-2">Access your cloud documents for better AI context.</p>
                <button 
                  onClick={handleConnectDrive}
                  disabled={isConnectingDrive}
                  className="text-xs bg-blue-600 text-white px-3 py-1.5 rounded font-medium hover:bg-blue-700 transition-colors w-full flex justify-center items-center gap-2"
                >
                  {isConnectingDrive ? 'Connecting...' : 'Connect Drive'}
                </button>
              </div>
            </div>
          </div>
        ) : (
           <div className="px-4 py-2 bg-green-50 border-b border-green-100 flex items-center gap-2 text-xs text-green-700 font-medium">
             <Check className="w-3 h-3" /> Google Drive Connected
           </div>
        )}

        <div className="flex-1 overflow-y-auto p-2 space-y-2">
          {filteredDocs.map(doc => (
            <div key={doc.id} className="p-3 rounded-lg border border-slate-100 hover:bg-slate-50 transition-colors group cursor-pointer">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${doc.type === 'pptx' ? 'bg-orange-100 text-orange-600' : 'bg-blue-100 text-blue-600'}`}>
                  <FileText className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-800 truncate">{doc.name}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs text-slate-400 flex items-center gap-1">
                      {doc.source === 'Google Drive' ? <Cloud className="w-3 h-3" /> : <HardDrive className="w-3 h-3" />}
                      {doc.source}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="p-4 border-t border-slate-100">
          <button 
            onClick={handleFileUpload}
            className="w-full py-2 border-2 border-dashed border-slate-300 rounded-lg text-slate-500 text-sm font-medium hover:border-primary hover:text-primary transition-colors flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Upload Local File
          </button>
        </div>
      </div>

      {/* Right: AI Generator */}
      <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
          <h2 className="font-bold text-slate-800 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            Proposal Generator
          </h2>
        </div>

        <div className="flex-1 flex flex-col p-6 overflow-hidden">
          <div className="mb-4">
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Describe the proposal you want to create
            </label>
            <div className="flex gap-2">
              <textarea
                className="flex-1 p-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500/20 resize-none h-24 text-sm"
                placeholder="E.g., Create a sales deck for Acme Corp focusing on our new AI analytics features. Use the Q3 template style."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              />
            </div>
            <div className="mt-2 flex justify-end">
               <button
                onClick={handleGenerate}
                disabled={isGenerating || !prompt}
                className={`px-4 py-2 rounded-lg text-sm font-medium text-white flex items-center gap-2 transition-all ${
                  isGenerating ? 'bg-purple-400 cursor-wait' : 'bg-purple-600 hover:bg-purple-700'
                }`}
              >
                {isGenerating ? (
                  <>Generating...</>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" /> Generate Draft
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="flex-1 border border-slate-200 rounded-lg bg-slate-50 overflow-hidden flex flex-col">
            <div className="p-2 bg-slate-100 border-b border-slate-200 text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Output Preview
            </div>
            <div className="flex-1 overflow-y-auto p-4 prose prose-sm max-w-none">
              {generatedContent ? (
                <div className="whitespace-pre-wrap font-mono text-sm text-slate-800">
                  {generatedContent}
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400">
                  <FileText className="w-12 h-12 mb-2 opacity-20" />
                  <p>Generated content will appear here</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default KnowledgeBase;
