import { GoogleGenAI, Type, Schema } from '@google/genai';
import { Email, EmailCategory, DocumentFile } from '../types';

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY, vertexai: true });

const MODEL_NAME = 'gemini-2.5-flash';

/**
 * Classifies emails and extracts summaries.
 */
export const processEmails = async (emails: Email[]): Promise<Email[]> => {
  if (emails.length === 0) return [];

  const prompt = `
    You are an executive assistant. Analyze the following emails.
    1. Categorize them into: Work, Sales, Personal, or Spam.
    2. Provide a 1-sentence summary.
    3. Determine if immediate action is required (true/false).
    
    Return a JSON array.
  `;

  const emailData = emails.map(e => ({
    id: e.id,
    sender: e.sender,
    subject: e.subject,
    body: e.body
  }));

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: {
        role: 'user',
        parts: [{ text: prompt + JSON.stringify(emailData) }]
      },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              category: { type: Type.STRING, enum: ['Work', 'Sales', 'Personal', 'Spam'] },
              summary: { type: Type.STRING },
              actionRequired: { type: Type.BOOLEAN }
            }
          }
        }
      }
    });

    const processedData = JSON.parse(response.text || '[]');
    
    // Merge AI results back into original email objects
    return emails.map(email => {
      const result = processedData.find((p: any) => p.id === email.id);
      if (result) {
        return {
          ...email,
          category: result.category as EmailCategory,
          summary: result.summary,
          actionRequired: result.actionRequired
        };
      }
      return email;
    });

  } catch (error) {
    console.error("Error processing emails:", error);
    return emails;
  }
};

/**
 * Generates a proposal based on selected documents and a user prompt.
 */
export const generateProposal = async (
  prompt: string, 
  documents: DocumentFile[]
): Promise<string> => {
  
  // Simulate RAG by passing document snippets
  const context = documents.map(d => `[File: ${d.name} (${d.source})]: ${d.contentSnippet}`).join('\n\n');

  const fullPrompt = `
    You are a sales expert. Create a professional proposal based on the user's request and the provided context documents.
    
    USER REQUEST: "${prompt}"
    
    AVAILABLE CONTEXT DOCUMENTS:
    ${context}
    
    Output format: Markdown.
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: {
        role: 'user',
        parts: [{ text: fullPrompt }]
      }
    });
    return response.text || "Failed to generate proposal.";
  } catch (error) {
    console.error("Error generating proposal:", error);
    return "Error generating proposal. Please check API key.";
  }
};

/**
 * Generates a quotation email and calculates price.
 */
export const generateQuotation = async (
  clientName: string,
  items: { description: string; cost: number }[],
  marginPercent: number
): Promise<{ emailBody: string; totalPrice: number }> => {
  
  const totalCost = items.reduce((sum, item) => sum + item.cost, 0);
  const totalPrice = totalCost * (1 + marginPercent / 100);

  const prompt = `
    Write a polite, professional email to ${clientName} attaching a quotation.
    
    Items:
    ${items.map(i => `- ${i.description}`).join('\n')}
    
    Total Price to Quote: $${totalPrice.toFixed(2)}
    
    Tone: Professional, persuasive, concise.
    Do not include subject line, just the body.
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: {
        role: 'user',
        parts: [{ text: prompt }]
      }
    });

    return {
      emailBody: response.text || "",
      totalPrice
    };
  } catch (error) {
    console.error("Error generating quote:", error);
    return { emailBody: "Error generating quote.", totalPrice };
  }
};
